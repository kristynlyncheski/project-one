var count = 0;

startButton.addEventListener("click", function(){
  openingPage.classList.add("hidden");
  gamePage.classList.remove("hidden");
  count += 1;
  console.log("count",count);
  startGame();
});


function startGame(){
  console.log("the game has started...");
  if (count < 4){
    rollButton.addEventListener("click", function(){
      console.log("roll cta clicked");
      count += 1;
      console.log("count in startGame",count);
      rollRandom();
    });
  }
  return count;
}

function rollRandom(){
  console.log("dice have been rolled...");

  for (var i = 0; i < rollDieArray.length; i++) {
    var randomDieRoll = Math.ceil(6 * Math.random());
    console.log("randomDieRoll is", randomDieRoll);

    for (var die in diceObj) {
      if (randomDieRoll === diceObj[die].dieValue){
        rollDieArray[i].src = diceObj[die].img;
      }
    }
  }
  rollCount();
}

function rollCount() {
  if (count < 4) {
    console.log("count in rollCount", count);
    rollNumber.innerText = "Roll #" + count;

  } else {
    rollNumber.innerText = "Player 2's Turn";
    count = 1;
    console.log("count is more than 4");
  }

  clickDie();
  return count;
}

function clickDie(){
  for (var i  = 0; i < rollDieArray.length; i++){
    rollDieArray[i].addEventListener("click", function(){
      console.log("this",this);
      this.classList.toggle("clicked");
      this.classList.toggle("notclicked");
    });
  }
}
